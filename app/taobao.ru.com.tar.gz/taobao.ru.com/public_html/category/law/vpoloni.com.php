<?php $catalogLink = '<a href="http://www.vpoloni.com" target="_blank"><img src="http://www.vpoloni.com/knopka.png" width="88" height="31" />
</a>'; include '../view.php';