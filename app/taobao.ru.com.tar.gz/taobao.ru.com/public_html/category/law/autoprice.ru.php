<?php $catalogLink = '<!-- begin of AutoPrice.RU informer -->
<style>
.A{text-decoration:none;font-size:7pt;font-weight:bold;color:darkGreen;}
.TBL{font-family:Verdana,Tahoma,sans-serif;font-size:7pt;color:#000000;background-color:cccc99;border-color:green;border-width:1pt;}
</style>
<table border=1 cellspacing=0 cellpadding=0 class=TBL><tr><td>
<table border=0 cellspacing=0 cellpadding=0 class=TBL>
<tr><td>
<script language=javascript src="http://www.autoprice.ru/api.cgi?limit=4&size=normal&type=grafic"></script>
</td></tr>
<tr><td align=center bgColor=cccc99>
<a href="http://www.autoprice.ru/" target=_blank style="font-family:Verdana,Tahoma,sans-serif;font-size:8pt;color:002000;text-decoration:none"><b>AutoPrice.RU</b></a>
</td></tr></table>
</table>
<!-- end of AutoPrice.RU informer -->'; include '../view.php';