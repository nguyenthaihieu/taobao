<?php $catalogLink = '<!-- BEGIN IncomeMax.com EXCHANGE CODE -->
<a href="http://www.incomemax.com/">
<img src="http://www.incomemax.com/recomended/imaxbutton.gif" border=0 alt="Make Money Online at IncomeMax.com"></a>
<!-- END IncomeMax.com EXCHANGE CODE -->'; include '../view.php';