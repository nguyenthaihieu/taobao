<?php $catalogLink = '<a href="http://www.cruiseshipshq.com">
Cruise Ships
</a>'; include '../view.php';