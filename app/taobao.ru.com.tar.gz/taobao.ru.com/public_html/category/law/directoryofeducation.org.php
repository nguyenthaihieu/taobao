<?php $catalogLink = 'Advance your career with an <a href="http://www.directoryofeducation.org" target="_blank">accredited online degree program</a>. Browse directoryofeducation.org to find the
top schools and colleges offering online degrees in fields including Business,
Marketing, Technology, Management, Design, Education, Psychology, Nursing, Paralegal
and more.'; include '../view.php';