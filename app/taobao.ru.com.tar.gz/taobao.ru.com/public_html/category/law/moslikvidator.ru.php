<?php $catalogLink = 'Юридические услуги по <a href="http://www.moslikvidator.ru/">ликвидации
предприятий</a> и сопровождению предприятий на стадии подготовки к ликвидации. <a href="http://www.moslikvidator.ru/">Ликвидация фирм</a>,
компаний и юридических лиц.'; include '../view.php';