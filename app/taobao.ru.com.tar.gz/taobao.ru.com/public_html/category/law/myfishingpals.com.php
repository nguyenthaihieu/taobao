<?php $catalogLink = '<!-- Start My Fishing Pals Link -->
<FONT face=helvetica,arial size=2 color="#3366CC"><b><a href="http://myfishingpals.com/">My Fishing Pals - Dedicated to Minnesota Fishing</a></b></font>
<!-- End My Fishing Pals Link -->'; include '../view.php';