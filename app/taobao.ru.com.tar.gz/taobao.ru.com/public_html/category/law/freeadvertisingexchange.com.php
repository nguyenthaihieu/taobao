<?php $catalogLink = '<a href="http://www.freeadvertisingexchange.com" target=_blank>Free Classified Advertising </a> - Reach thousands daily! Always free!<br>
We provide free classified advertising, free categorized link exchange directory, 
and free banner tools!<br>'; include '../view.php';