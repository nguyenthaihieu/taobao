<?php $catalogLink = '<b><a href="http://www.exittraffic.us">
ExitTraffic.us - Your #1 FREE Exit Traffic Exchange Program</a></b>'; include '../view.php';